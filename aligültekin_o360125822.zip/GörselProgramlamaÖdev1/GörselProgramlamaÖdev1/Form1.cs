﻿using System;
using System.Reflection.Emit;
using System.Windows.Forms;

namespace GörselProgramlamaÖdev1
{
    public partial class Form1 : Form
    {
        Timer timer = new Timer();
        DateTime systemTime;
        DateTime currentTime;
        DateTime targetTime;
        bool countForward = true;
        bool isRunning = false;

        public Form1()
        {
            InitializeComponent();
           
            timer.Interval = 100; 
            timer.Tick += Timer_Tick;

            
            this.Load += Form1_Load;
            button1.Click += button1_Click;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            systemTime = DateTime.Now;
            UpdateTopLabels(systemTime);
            UpdateBottomLabels(TimeSpan.Zero);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (isRunning) return;

            button1.Enabled = false;
            systemTime = DateTime.Now;

            if (countForward)
            {
                currentTime = systemTime.AddMinutes(-2); 
                targetTime = systemTime;
            }
            else
            {
                currentTime = systemTime.AddMinutes(2);  
                targetTime = systemTime;
            }

            UpdateBottomLabels(systemTime.TimeOfDay);

            isRunning = true;
            timer.Start();  
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            if (countForward)
            {
                if (currentTime >= targetTime)
                {
                    StopTimer();
                }
                else
                {
                    currentTime = currentTime.AddMilliseconds(timer.Interval);
                    UpdateTopLabels(currentTime);
                }
            }
            else
            {
                if (currentTime <= targetTime)
                {
                    StopTimer();
                }
                else
                {
                    currentTime = currentTime.AddMilliseconds(-timer.Interval);
                    UpdateTopLabels(currentTime);
                }
            }
        }

        private void StopTimer()
        {
            timer.Stop();
            isRunning = false;
            countForward = !countForward; 
            button1.Enabled = true;
        }

        private void UpdateTopLabels(DateTime dt)
        {
            label1.Text = dt.Hour.ToString("00");
            label2.Text = dt.Minute.ToString("00");
            label3.Text = dt.Second.ToString("00");
            label4.Text = dt.Millisecond.ToString("000");
        }

        private void UpdateBottomLabels(TimeSpan ts)
        {
            label5.Text = ts.Hours.ToString("00");
            label6.Text = ts.Minutes.ToString("00");
            label7.Text = ts.Seconds.ToString("00");
            label8.Text = ts.Milliseconds.ToString("000");
        }
    }
}
