public class Gorev
{
    public int id;
    public string baslik;
    public string saat; // "HH:mm" format�nda tutaca��z
}